<hr> 
<div class="panel panel-gradient" >
 
 
				<img src="uploads/img/tb.png"  alt="" />
	      
           
</div>