<hr> 
<div class="panel panel-gradient" >
 
 
				<img src="uploads/img/cl.png"  alt="" />
	      
           
</div>