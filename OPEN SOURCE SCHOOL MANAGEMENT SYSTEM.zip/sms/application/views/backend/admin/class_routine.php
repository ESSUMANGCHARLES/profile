<hr> 
<div class="panel panel-gradient" >
 
 
				<img src="uploads/img/ru.png"  alt="" />
	      
           
</div>